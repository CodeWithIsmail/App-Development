package com.example.check_weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
