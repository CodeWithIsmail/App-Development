import 'package:flutter/material.dart';

const KAppBarTextStyle=TextStyle(
  fontSize: 25,
  letterSpacing: 2,
  color: Colors.white
);